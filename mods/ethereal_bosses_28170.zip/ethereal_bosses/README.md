### Ethereal Bosses (Reworked)
---

![EB](https://codeberg.org/pixelzone/ethereal_bosses_reworked/raw/branch/main/EtherealBosses.png)

"Ethereal Bosses", is a mod focused on "PVE" combat, adding pets, monsters, and bosses to your world.

---
---
- BY : DUCKGO
- CREDITS : TenPlus1
- LICENSE : MIT
- TEXTURE : CC BY-SA 4.0 
- 
- depends = Mobs
- optional_depends = hunger_ng,3d_armor,ethereal,mcl_core
---

1 - [Getting Starded](https://codeberg.org/pixelzone/ethereal_bosses_reworked/src/branch/main/eb_Wiki/Getting_Starded.md)

2 - [Mobs](https://codeberg.org/pixelzone/ethereal_bosses_reworked/src/branch/main/eb_Wiki/Mobs.md)

3 - [Itens](https://codeberg.org/pixelzone/ethereal_bosses_reworked/src/branch/main/eb_Wiki/Itens.md)

4 - [Recipes](https://codeberg.org/pixelzone/ethereal_bosses_reworked/src/branch/main/eb_Wiki/Recipes.md) 


---
---
### Have fun! ..

