## Mobs
---
---

## Depths Eye 

 HP : 20
  
 Damge : 3
 

## Ice Monster

 HP : 80
  
 Damge : 15
 
 
## Nature Guardian

 HP : 80
  
 Damge : 8
 
---
## Fungs

 HP : 80
  
 Damge : 5
 
 Follow : Rotten Wood
 
 
## Pixies

 HP : 80
  
 Damge : 3
 
 Follow : Nectar
 
 
---
## Crazy Mushroom Boss 

 HP : 1100
  
 Damge : 18


## Heated Boss

 HP : 1300
  
 Damge : 20


## Frosty Queen Boss

 HP : 1500
  
 Damge : 5
 
 Attack 2 : Summons Ice Monsters..
 

---
##Elder

 HP : ...
  
 Damge : 0
 
