### Getting Starded
---
---
- 1 - Start exploring and obtaining resources, become as strong as possible.

- 2 - At some point you may meet the "Elder", he has something to say..

- 3 - You can tame some pets to be your companions. See [here](https://codeberg.org/pixelzone/ethereal_bosses_reworked/src/branch/main/eb_Wiki/Mobs.md) what you need.

- 4 - Once you are strong, find the bosses and get the trophies they drop.
