## Recipes

---

---

### Miracle Healing

    [ ] [Nectar          ] [ ]
    [ ] [ Eye            ] [ ]
    [ ] [ Queen's bottle ] [ ]

### Queen's bottle

    [ ] [             ] [  ]
    [ ] [ Group Glass ] [ ]
    [ ] [             ] [ ]

---

### Mushroom Pickaxe

    [Group Mushroom] [Group Mushroom] [Group Mushroom]
    [              ] [ Group Stick  ] [              ]
    [              ] [ Group Stick  ] [              ]



-

### Mushroom Shovel

    [ ] [Group Mushroom] [ ]
    [ ] [ Group Stick  ] [ ]
    [ ] [ Group Stick  ] [ ]

-

### Mushroom Mushroom Axe

    [Group Mushroom] [Group Mushroom] [   ]
    [Group Mushroom] [Group Mushroom] [   ]
    [              ] [ Group Stick  ] [   ]

-

### Mushroom Sword

    [   ] [Group Mushroom] [ ]
    [   ] [Group Mushroom] [ ]
    [   ] [ Group Stick  ] [ ]

-

### Nature Whip

    [            ] [ Nature Roots] [ ]
    [Nature Roots] [ Group Stick ] [ ]
    [            ] [ Group Stick ] [ ]

-

### Nature

    [   ] [ Group Stone ] [ ]
    [   ] [ Nature Roots] [ ]
    [   ] [ Group Stick ] [ ]

---

### Nectar

    [ Flower ] [ Flower ] [ Flower ]

-

### Nature Rod

    [   ] [ Tree  ] [ Water Bucket ]
