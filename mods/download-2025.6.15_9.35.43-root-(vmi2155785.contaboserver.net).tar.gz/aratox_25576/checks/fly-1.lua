local frozen_players = {}
local oldpos = {}

local function fly_check(player)
	local pos = player:get_pos()
	if not pos then return true end

	local name = player:get_player_name()
	if minetest.check_player_privs(name, {fly = true}) then
		return true
	end

	local node = minetest.get_node(pos).name
	local node_below = minetest.get_node({x = pos.x, y = pos.y - 1, z = pos.z}).name

	if node == "air" and node_below == "air" then
		local airnodes = minetest.find_nodes_in_area(
			{x = pos.x - 2, y = pos.y - 2, z = pos.z - 2},
			{x = pos.x + 2, y = pos.y + 2, z = pos.z + 2},
			{"air"}
		)
		local v = player:get_player_velocity()
		if #airnodes >= 125 and v.y >= 0 then
			return false
		end
	end

	return true
end

local function unfreeze_player(player)
	local name = player:get_player_name()
	if frozen_players[name] then
		player:set_physics_override({speed = 1, jump = 1, gravity = 1})
		frozen_players[name] = nil
	end
end

local function check_if_landed(player)
	local name = player:get_player_name()
	local pos = player:get_pos()
	local node_below = minetest.get_node({x = pos.x, y = pos.y - 1, z = pos.z}).name

	if node_below ~= "air" then
		unfreeze_player(player)
	else
		minetest.after(0.5, check_if_landed, player) -- check again after delay
	end
end

function aratox_checks.fly_1()
	local players = minetest.get_connected_players()
	for _, player in ipairs(players) do
		local name = player:get_player_name()
		local pos = player:get_pos()

		if not fly_check(player) then
			if not frozen_players[name] then
				oldpos[name] = pos
				frozen_players[name] = true
				player:set_physics_override({speed = 0, jump = 0, gravity = 0}) -- freeze

				minetest.chat_send_player(name, "§cYou have been frozen by AntiCheat for flying!")

				minetest.after(0.5, check_if_landed, player) -- start checking if they landed
				minetest.after(10, function() -- safety unfreeze after 10s
					if frozen_players[name] then
						unfreeze_player(player)
					end
				end)
			end
		else
			unfreeze_player(player) -- restore physics if they are no longer flying
		end
	end
end
