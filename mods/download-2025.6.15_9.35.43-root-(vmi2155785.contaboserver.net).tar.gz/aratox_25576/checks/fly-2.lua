local cheatcount = {}
local frozen_players = {}

-- Unfreeze logic
local function unfreeze_player(player)
	local name = player:get_player_name()
	if frozen_players[name] then
		player:set_physics_override({speed = 1, jump = 1, gravity = 1})
		frozen_players[name] = nil
	end
end

-- Land check loop
local function check_if_landed(player)
	local name = player:get_player_name()
	local pos = player:get_pos()
	local node_below = minetest.get_node({x = pos.x, y = pos.y - 1, z = pos.z}).name

	if node_below ~= "air" then
		unfreeze_player(player)
	else
		minetest.after(0.5, check_if_landed, player)
	end
end

-- Main check
function aratox_checks.fly_2()
	local players = minetest.get_connected_players()
	for _, player in ipairs(players) do
		local name = player:get_player_name()
		local pos = player:get_pos()

		if minetest.check_player_privs(name, {fly = true}) then
			-- Skip if player has fly privilege
		else
			local velo = player:get_velocity()
			local vY = math.abs(velo.y)

			local nodes_air = true
			for dx = -1, 1 do
				for dz = -1, 1 do
					local n = minetest.get_node({x = pos.x + dx, y = pos.y - 1, z = pos.z + dz}).name
					if n ~= "air" then
						nodes_air = false
						break
					end
				end
				if not nodes_air then break end
			end

			if vY == 0 and nodes_air then
				cheatcount[name] = (cheatcount[name] or 0) + 1

				if cheatcount[name] >= 5 then
					if not frozen_players[name] then
						player:set_physics_override({speed = 0, jump = 0, gravity = 0})
						frozen_players[name] = true

						minetest.chat_send_player(name, "§cYou have been frozen by AntiCheat for flying (fly_2)!")

						minetest.after(0.5, check_if_landed, player)
						minetest.after(10, function()
							if frozen_players[name] then
								unfreeze_player(player)
							end
						end)
					end
					cheatcount[name] = nil
				end
			end
		end
	end
end
