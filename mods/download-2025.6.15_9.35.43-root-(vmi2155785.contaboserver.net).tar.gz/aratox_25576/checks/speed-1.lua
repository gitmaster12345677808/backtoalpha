local frozen_players = {}

-- Unfreeze helper
local function unfreeze_player(player)
	local name = player:get_player_name()
	if frozen_players[name] then
		player:set_physics_override({speed = 1, jump = 1, gravity = 1})
		frozen_players[name] = nil
	end
end

-- Freeze until they stop speeding or timeout
local function check_speed_restore(player)
	local name = player:get_player_name()
	local velo = player:get_player_velocity()
	local speed_limit = tonumber(minetest.settings:get("movement_speed_walk"))

	if math.abs(velo.x) <= speed_limit and math.abs(velo.z) <= speed_limit then
		unfreeze_player(player)
	else
		minetest.after(0.5, check_speed_restore, player)
	end
end

-- Speed detection logic
function aratox_checks.speed_1()
	local speed_limit = tonumber(minetest.settings:get("movement_speed_walk"))
	local players = minetest.get_connected_players()

	for _, player in ipairs(players) do
		local name = player:get_player_name()

		-- Skip players with "fast" privilege (admins or trusted users)
		if minetest.check_player_privs(name, {fast = true}) then
			unfreeze_player(player) -- just in case they're frozen previously
		else
			local v = player:get_player_velocity()

			if math.abs(v.x) > speed_limit or math.abs(v.z) > speed_limit then
				if not frozen_players[name] then
					minetest.chat_send_player(name, "§cYou have been frozen for speed hacking (speed_1)!")
					player:set_physics_override({speed = 0, jump = 0, gravity = 0})
					frozen_players[name] = true

					minetest.after(0.5, check_speed_restore, player)
					minetest.after(10, function()
						if frozen_players[name] then
							unfreeze_player(player)
						end
					end)
				end
			else
				unfreeze_player(player)
			end
		end
	end
end
