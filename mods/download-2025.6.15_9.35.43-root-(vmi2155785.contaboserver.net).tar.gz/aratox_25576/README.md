# Aratox
Minetest Anticheat. Remove cheaters from your server faster.

#### Features
* "Auto-Kicks", Automaic Kicks to remove cheaters from the game insted of live cheat-prevention.
* Very reliable Speed and Fly detection
* Integration of the minetest-engine cheat detection
* Easy check configuration (enabling and disabling)
* ...

#### Checks
* Fly
* Speed
* Integration of Minetest on_cheat

#### Important Notice
Part of the code was written by by AMTAC under GPL-3.0. You can view the AMTAC Anticheat repositoy [here](https://github.com/Minetest-j45/Advanced-MineTest-AntiCheat).